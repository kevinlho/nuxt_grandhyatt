# Nuxt CMS (Clean Architecture)

Nuxt 4 + Nuxt UI v4 + Axios. Dummy data by default.

```bash
npm install
cp .env.example .env
npm run dev
```
Login: `admin@example.com` / `password`

## Structure
```
app/
  domain/            # pure TS, no framework deps
    entities/        # User, Product, Auth, Pagination
    repositories/    # interfaces (contracts)
    usecases/        # business rules + validation
  data/
    datasources/dummy/   # in-memory seed data
    repositories/dummy/  # Dummy*Repository implements domain interfaces
    repositories/api/    # Api*Repository (axios) implements same interfaces
  infrastructure/
    http/httpClient.ts   # axios + bearer + auto refresh token
    storage/tokenStorage.ts
  di/container.ts    # wires repos -> usecases, dummy vs api switch
  plugins/di.client.ts   # provides $di
  composables/       # useAuth, useCrud (presentation logic)
  middleware/auth.global.ts  # route guard
  layouts/ pages/ components/  # UI
```
Dependency rule: `presentation -> domain <- data/infrastructure`. Pages only talk to use cases via `$di`.

## Switching to the real API
Set `NUXT_PUBLIC_USE_DUMMY=false` and `NUXT_PUBLIC_API_BASE_URL`. Expected endpoints:

| Method | Path | Body / Response |
|---|---|---|
| POST | /auth/login | `{email,password}` → `{tokens:{accessToken,refreshToken}, user}` |
| POST | /auth/refresh | `{refreshToken}` → `{accessToken,refreshToken}` |
| POST | /auth/logout | – |
| GET | /users?page&pageSize&search | `{items,total,page,pageSize}` |
| GET/PUT/DELETE | /users/:id | |
| POST | /users | |
| (same) | /products | |

Adjust response mapping inside `data/repositories/api/*` if your backend shape differs — nothing else changes.

## Auto refresh flow
1. Request interceptor attaches `Authorization: Bearer <access>`.
2. On 401, the first failing request calls `/auth/refresh` (via a bare axios instance, no interceptors).
3. Other 401s during that time await the **same** refresh promise, then retry with the new token.
4. If refresh fails → tokens cleared → redirect to `/login`.
5. Requests flagged `{ skipAuth: true }` (login/refresh) are never retried.
