<script setup lang="ts">
import type { Product, ProductInput } from '~/domain/entities/Product'

const open = defineModel<boolean>('open', { default: false })
const props = defineProps<{ product?: Product | null; saving?: boolean }>()
const emit = defineEmits<{ submit: [input: ProductInput] }>()

const empty = (): ProductInput => ({ name: '', sku: '', category: 'Electronics', price: 0, stock: 0, isActive: true })
const form = reactive<ProductInput>(empty())

watch(open, (v) => {
  if (!v) return
  if (props.product) {
    const { id, createdAt, ...rest } = props.product
    Object.assign(form, rest)
  } else Object.assign(form, empty())
})

const categories = ['Electronics', 'Apparel', 'Home', 'Beauty', 'Sports']
</script>

<template>
  <UModal v-model:open="open" :title="product ? 'Edit Product' : 'Add Product'">
    <template #body>
      <form id="product-form" class="space-y-4" @submit.prevent="emit('submit', { ...form })">
        <UFormField label="Name" required><UInput v-model="form.name" class="w-full" /></UFormField>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <UFormField label="SKU" required><UInput v-model="form.sku" class="w-full" /></UFormField>
          <UFormField label="Category"><USelect v-model="form.category" :items="categories" class="w-full" /></UFormField>
          <UFormField label="Price (IDR)"><UInputNumber v-model="form.price" :min="0" :step="1000" class="w-full" /></UFormField>
          <UFormField label="Stock"><UInputNumber v-model="form.stock" :min="0" class="w-full" /></UFormField>
        </div>
        <USwitch v-model="form.isActive" label="Active" />
      </form>
    </template>
    <template #footer>
      <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 w-full">
        <UButton color="neutral" variant="outline" label="Cancel" class="justify-center" @click="open = false" />
        <UButton type="submit" form="product-form" label="Save" :loading="saving" class="justify-center" />
      </div>
    </template>
  </UModal>
</template>
