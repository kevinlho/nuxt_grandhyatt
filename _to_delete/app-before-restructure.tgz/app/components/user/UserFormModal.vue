<script setup lang="ts">
import type { User, UserInput } from '~/domain/entities/User'

const open = defineModel<boolean>('open', { default: false })
const props = defineProps<{ user?: User | null; saving?: boolean }>()
const emit = defineEmits<{ submit: [input: UserInput] }>()

const empty = (): UserInput => ({ name: '', email: '', role: 'viewer', status: 'active' })
const form = reactive<UserInput>(empty())

watch(open, (v) => {
  if (!v) return
  Object.assign(form, props.user
    ? { name: props.user.name, email: props.user.email, role: props.user.role, status: props.user.status }
    : empty())
})

const roles = ['admin', 'editor', 'viewer']
const statuses = ['active', 'inactive']
</script>

<template>
  <UModal v-model:open="open" :title="user ? 'Edit User' : 'Add User'">
    <template #body>
      <form id="user-form" class="space-y-4" @submit.prevent="emit('submit', { ...form })">
        <UFormField label="Name" required><UInput v-model="form.name" class="w-full" /></UFormField>
        <UFormField label="Email" required><UInput v-model="form.email" type="email" class="w-full" /></UFormField>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <UFormField label="Role"><USelect v-model="form.role" :items="roles" class="w-full" /></UFormField>
          <UFormField label="Status"><USelect v-model="form.status" :items="statuses" class="w-full" /></UFormField>
        </div>
      </form>
    </template>
    <template #footer>
      <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 w-full">
        <UButton color="neutral" variant="outline" label="Cancel" class="justify-center" @click="open = false" />
        <UButton type="submit" form="user-form" label="Save" :loading="saving" class="justify-center" />
      </div>
    </template>
  </UModal>
</template>
