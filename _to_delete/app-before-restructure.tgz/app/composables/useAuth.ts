import type { AuthUser, LoginCredentials } from '~/domain/entities/Auth'
import { tokenStorage } from '~/infrastructure/storage/tokenStorage'

export function useAuth() {
  const { $di } = useNuxtApp()
  const user = useState<AuthUser | null>('auth.user', () => tokenStorage.getUser())
  const isLoggedIn = computed(() => !!user.value && !!tokenStorage.getAccessToken())

  async function login(c: LoginCredentials) {
    const res = await $di.login.execute(c)
    tokenStorage.setTokens(res.tokens)
    tokenStorage.setUser(res.user)
    user.value = res.user
  }

  async function logout() {
    try { await $di.logout.execute() } catch { /* ignore */ }
    tokenStorage.clear()
    user.value = null
    await navigateTo('/login')
  }

  return { user, isLoggedIn, login, logout }
}
