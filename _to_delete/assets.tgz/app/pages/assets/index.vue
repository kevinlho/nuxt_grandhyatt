<script setup lang="ts">
import type { TableColumn } from '@nuxt/ui'
import { ASSET_CATEGORIES, conditionColor, type Asset, type AssetInput } from '~/types/asset'

definePageMeta({ permission: 'assets.view' })
const { $api } = useNuxtApp()
const { can } = usePermission()
const canCreate = computed(() => can('assets.create'))
const canDelete = computed(() => can('assets.delete'))

const { items, total, loading, saving, query, load, save, remove } = useCrud<Asset, AssetInput>($api.assets, 'Asset', validateAsset)

const { data: deptList } = await useAsyncData('assets.departments', () =>
  can('departments.view') ? $api.departments.list({ page: 1, pageSize: 500 }).then(r => r.items).catch(() => []) : Promise.resolve([]))
const deptName = (id?: string | null) => (id && deptList.value?.find(d => d.id === id)?.name) || '—'

// summary + tag list for auto-numbering (all assets, not just this page)
const { data: summary, refresh: refreshSummary } = await useAsyncData('assets.summary', async () => {
  const all = (await $api.assets.list({ page: 1, pageSize: 5000 })).items
  return { tags: all.map(a => a.tag), value: all.reduce((s, a) => s + (a.value ?? 0), 0), damaged: all.filter(a => a.condition === 'damaged').length }
})

const category = ref('all')
const dept = ref('all')
const categoryItems = [{ label: 'All categories', value: 'all' }, ...ASSET_CATEGORIES.map(c => ({ label: c, value: c }))]
const deptItems = computed(() => [{ label: 'All departments', value: 'all' }, { label: 'No department', value: 'none' }, ...(deptList.value ?? []).map(d => ({ label: d.name, value: d.id }))])
watch(category, v => { query.category = v === 'all' ? '' : v })
watch(dept, v => { query.departmentId = v === 'all' ? '' : v })

const formOpen = ref(false)
const deleteOpen = ref(false)
const selected = ref<Asset | null>(null)
async function onSubmit(input: AssetInput) {
  if (await save(input)) { formOpen.value = false; refreshSummary() }
}
function openDelete(a: Asset) { selected.value = a; deleteOpen.value = true }
async function onDelete() {
  if (!selected.value) return
  await remove(selected.value.id)
  deleteOpen.value = false
  refreshSummary()
}

const date = (s?: string) => s ? new Date(s).toLocaleDateString('id-ID') : '—'
const columns: TableColumn<Asset>[] = [
  { accessorKey: 'tag', header: 'Tag' },
  { accessorKey: 'name', header: 'Asset' },
  { accessorKey: 'departmentId', header: 'Department', cell: ({ row }) => deptName(row.original.departmentId) },
  { accessorKey: 'location', header: 'Location' },
  { accessorKey: 'condition', header: 'Condition' },
  { accessorKey: 'value', header: 'Value', cell: ({ row }) => row.original.value != null ? idr(row.original.value) : '—' },
  { accessorKey: 'purchaseDate', header: 'Purchased', cell: ({ row }) => date(row.original.purchaseDate) },
  { id: 'actions', header: '' }
]
onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <div class="flex items-center justify-between gap-3">
      <div>
        <h1 class="text-xl sm:text-2xl font-semibold">Assets</h1>
        <p class="text-sm text-(--ui-text-muted)">Hotel equipment and property, by department and location.</p>
      </div>
      <UButton v-if="canCreate" icon="i-lucide-plus" label="Add Asset" :ui="{ label: 'hidden sm:inline' }" aria-label="Add Asset" @click="formOpen = true" />
    </div>

    <div v-if="summary" class="grid grid-cols-3 gap-3">
      <UCard :ui="{ body: 'p-3 sm:p-4' }"><p class="text-xs text-(--ui-text-muted)">Assets</p><p class="text-lg font-semibold">{{ summary.tags.length }}</p></UCard>
      <UCard :ui="{ body: 'p-3 sm:p-4' }"><p class="text-xs text-(--ui-text-muted)">Total value</p><p class="text-sm sm:text-lg font-semibold break-words">{{ idr(summary.value) }}</p></UCard>
      <UCard :ui="{ body: 'p-3 sm:p-4' }"><p class="text-xs text-(--ui-text-muted)">Damaged</p><p class="text-lg font-semibold" :class="summary.damaged && 'text-(--ui-error)'">{{ summary.damaged }}</p></UCard>
    </div>

    <UCard :ui="{ body: 'p-0 sm:p-0' }">
      <div class="p-4 border-b border-(--ui-border) flex flex-col sm:flex-row gap-2">
        <UInput v-model="query.search" icon="i-lucide-search" placeholder="Search tag, name, location…" class="w-full sm:max-w-xs" />
        <USelect v-model="category" :items="categoryItems" class="w-full sm:w-44" aria-label="Filter by category" />
        <USelect v-if="deptList?.length" v-model="dept" :items="deptItems" icon="i-lucide-building-2" class="w-full sm:w-48" aria-label="Filter by department" />
      </div>

      <UTable class="hidden md:block" :data="items" :columns="columns" :loading="loading">
        <template #tag-cell="{ row }"><span class="font-mono text-sm">{{ row.original.tag }}</span></template>
        <template #name-cell="{ row }">
          <p class="font-medium">{{ row.original.name }}</p>
          <p class="text-xs text-(--ui-text-muted)">{{ row.original.category }}<template v-if="row.original.notes"> · {{ row.original.notes }}</template></p>
        </template>
        <template #condition-cell="{ row }"><UBadge :label="row.original.condition" :color="conditionColor[row.original.condition]" variant="subtle" class="capitalize" /></template>
        <template #actions-cell="{ row }">
          <div v-if="canDelete" class="flex justify-end">
            <UButton icon="i-lucide-trash-2" size="sm" color="error" variant="ghost" :aria-label="`Delete ${row.original.name}`" @click="openDelete(row.original)" />
          </div>
        </template>
        <template #empty><p class="py-6 text-center text-sm text-(--ui-text-muted)">No assets found.</p></template>
      </UTable>

      <ul class="md:hidden divide-y divide-(--ui-border)">
        <li v-if="loading" v-for="i in 4" :key="`sk${i}`" class="p-4"><USkeleton class="h-14" /></li>
        <li v-else-if="!items.length" class="p-6 text-center text-sm text-(--ui-text-muted)">No assets found.</li>
        <li v-for="a in (loading ? [] : items)" :key="a.id" class="p-4 flex items-start gap-3">
          <div class="flex-1 min-w-0">
            <p class="font-medium truncate">{{ a.name }}</p>
            <p class="text-xs text-(--ui-text-muted) truncate"><span class="font-mono">{{ a.tag }}</span> · {{ a.category }}</p>
            <p class="text-xs text-(--ui-text-muted) truncate">{{ deptName(a.departmentId) }} · {{ a.location }}</p>
            <div class="mt-2 flex flex-wrap gap-1.5 items-center">
              <UBadge :label="a.condition" :color="conditionColor[a.condition]" variant="subtle" class="capitalize" />
              <span v-if="a.value != null" class="text-xs">{{ idr(a.value) }}</span>
            </div>
          </div>
          <UButton v-if="canDelete" icon="i-lucide-trash-2" color="error" variant="ghost" class="-mr-2" :aria-label="`Delete ${a.name}`" @click="openDelete(a)" />
        </li>
      </ul>

      <div class="p-4 border-t border-(--ui-border) flex flex-col-reverse sm:flex-row gap-3 justify-between items-center text-sm">
        <span class="text-(--ui-text-muted)">{{ total }} assets</span>
        <UPagination :sibling-count="1" show-edges v-model:page="query.page" :items-per-page="query.pageSize" :total="total" />
      </div>
    </UCard>

    <AssetFormModal v-model:open="formOpen" :departments="deptList ?? []" :existing-tags="summary?.tags ?? []" :saving="saving" @submit="onSubmit" />
    <CommonConfirmDialog v-model:open="deleteOpen" title="Delete asset?" :message="`${selected?.tag} · ${selected?.name} will be removed permanently.`" @confirm="onDelete" />
  </div>
</template>
