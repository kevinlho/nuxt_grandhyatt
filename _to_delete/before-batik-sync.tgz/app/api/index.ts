import type { AxiosInstance } from 'axios'
import type { Product, ProductInput } from '~/types/product'
import type { User, UserInput } from '~/types/user'
import { authApi } from './auth'
import { crudApi } from './crud'
import { mockAuthApi } from './mock/auth'
import { mockCrud } from './mock/crud'
import { products, users } from './mock/db'

/** All backend calls in one place. Add a new resource = one line here. */
export function createApi(http: AxiosInstance, useDummy: boolean) {
  if (useDummy) {
    return {
      auth: mockAuthApi,
      users: mockCrud<User, UserInput>(users, {
        label: 'User', searchFields: ['name', 'email', 'role'],
        unique: (rows, i, id) => rows.some(u => u.email === i.email && u.id !== id) ? 'Email already exists' : undefined
      }),
      products: mockCrud<Product, ProductInput>(products, {
        label: 'Product', searchFields: ['name', 'sku', 'category'],
        unique: (rows, i, id) => rows.some(p => p.sku === i.sku && p.id !== id) ? 'SKU already exists' : undefined
      })
    }
  }
  return {
    auth: authApi(http),
    users: crudApi<User, UserInput>(http, '/users'),
    products: crudApi<Product, ProductInput>(http, '/products')
  }
}

export type Api = ReturnType<typeof createApi>
