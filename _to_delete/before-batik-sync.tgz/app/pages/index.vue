<script setup lang="ts">
const { $api } = useNuxtApp()
const { user } = useAuth()

const { data, pending } = await useAsyncData('dashboard', async () => {
  const [u, p] = await Promise.all([
    $api.users.list({ page: 1, pageSize: 1000 }),
    $api.products.list({ page: 1, pageSize: 1000 })
  ])
  return {
    totalUsers: u.total,
    activeUsers: u.items.filter(x => x.status === 'active').length,
    totalProducts: p.total,
    lowStock: p.items.filter(x => x.stock < 10),
    inventoryValue: p.items.reduce((s, x) => s + x.price * x.stock, 0),
    recentUsers: u.items.slice(0, 5)
  }
})

const idr = (n: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n)
const stats = computed(() => data.value ? [
  { label: 'Total Users', value: data.value.totalUsers, icon: 'i-lucide-users' },
  { label: 'Active Users', value: data.value.activeUsers, icon: 'i-lucide-user-check' },
  { label: 'Products', value: data.value.totalProducts, icon: 'i-lucide-package' },
  { label: 'Inventory Value', value: idr(data.value.inventoryValue), icon: 'i-lucide-wallet' }
] : [])
</script>

<template>
  <div class="space-y-6">
    <div>
      <h1 class="text-xl sm:text-2xl font-semibold">Dashboard</h1>
      <p class="text-(--ui-text-muted)">Welcome back, {{ user?.name }}</p>
    </div>

    <div class="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
      <UCard v-for="s in stats" :key="s.label">
        <div class="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
          <div class="self-start p-2 rounded-lg bg-primary/10"><UIcon :name="s.icon" class="size-6 text-primary" /></div>
          <div class="min-w-0">
            <p class="text-xs sm:text-sm text-(--ui-text-muted)">{{ s.label }}</p>
            <p class="text-base sm:text-xl font-semibold break-words">{{ s.value }}</p>
          </div>
        </div>
      </UCard>
      <USkeleton v-if="pending" v-for="i in 4" :key="i" class="h-20" />
    </div>

    <div v-if="data" class="grid gap-4 lg:grid-cols-2">
      <UCard>
        <template #header><h2 class="font-semibold">Recent Users</h2></template>
        <ul class="divide-y divide-(--ui-border)">
          <li v-for="u in data.recentUsers" :key="u.id" class="py-2 flex justify-between items-center gap-3 text-sm">
            <span class="min-w-0 truncate">{{ u.name }} <span class="text-(--ui-text-muted)">· {{ u.email }}</span></span>
            <UBadge :label="u.role" variant="subtle" class="shrink-0" />
          </li>
        </ul>
      </UCard>
      <UCard>
        <template #header><h2 class="font-semibold">Low Stock (&lt; 10)</h2></template>
        <p v-if="!data.lowStock.length" class="text-sm text-(--ui-text-muted)">All good.</p>
        <ul v-else class="divide-y divide-(--ui-border)">
          <li v-for="p in data.lowStock" :key="p.id" class="py-2 flex justify-between items-center gap-3 text-sm">
            <span class="min-w-0 truncate">{{ p.name }} <span class="text-(--ui-text-muted)">· {{ p.sku }}</span></span>
            <UBadge :label="`${p.stock} left`" color="warning" variant="subtle" class="shrink-0" />
          </li>
        </ul>
      </UCard>
    </div>
  </div>
</template>
