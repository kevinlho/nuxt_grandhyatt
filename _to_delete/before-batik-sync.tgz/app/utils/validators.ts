import type { ProductInput } from '~/types/product'
import type { UserInput } from '~/types/user'

// Quick client-side checks for nicer UX. The Go backend is still the source of truth.
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function validateUser(i: UserInput) {
  if (!i.name.trim()) return 'Name is required'
  if (!EMAIL_RE.test(i.email)) return 'Invalid email'
}

export function validateProduct(i: ProductInput) {
  if (!i.name.trim()) return 'Name is required'
  if (!i.sku.trim()) return 'SKU is required'
  if (i.price < 0) return 'Price cannot be negative'
  if (i.stock < 0) return 'Stock cannot be negative'
}
