# Nuxt CMS

Nuxt 4 + Nuxt UI v4 + Axios. Dummy data by default.

```bash
npm install
cp .env.example .env
npm run dev
```
Login: `admin@example.com` / `password`

## Structure
```
app/
  types/            # User, Product, Auth, Pagination (interfaces only)
  api/
    http.ts         # axios + bearer + auto refresh token
    crud.ts         # crudApi<T, I>(http, '/path') -> list/get/create/update/remove
    auth.ts         # login / refresh / logout
    mock/           # in-memory versions with the same shape (dummy mode)
    index.ts        # createApi(): picks real vs mock — register new resources here
  plugins/api.client.ts  # provides $api
  utils/            # tokenStorage, validators (auto-imported)
  composables/      # useAuth, useCrud(api, label, validate?)
  middleware/auth.global.ts  # route guard
  layouts/ pages/ components/  # UI
```
Pages call `$api` directly, usually through `useCrud`.

### Adding a new resource (e.g. Article)
1. `types/article.ts` — `Article` + `ArticleInput`
2. `api/index.ts` — `articles: crudApi<Article, ArticleInput>(http, '/articles')` (+ a `mockCrud` line for dummy mode)
3. optional `validateArticle` in `utils/validators.ts`
4. `pages/articles/index.vue` with `useCrud($api.articles, 'Article', validateArticle)` + a form modal

## Switching to the real API
Set `NUXT_PUBLIC_USE_DUMMY=false` and `NUXT_PUBLIC_API_BASE_URL`. Expected endpoints:

| Method | Path | Body / Response |
|---|---|---|
| POST | /auth/login | `{email,password}` → `{tokens:{accessToken,refreshToken}, user}` |
| POST | /auth/refresh | `{refreshToken}` → `{accessToken,refreshToken}` |
| POST | /auth/logout | – |
| GET | /users?page&pageSize&search | `{items,total,page,pageSize}` |
| GET/PUT/DELETE | /users/:id | |
| POST | /users | |
| (same) | /products | |

Adjust response mapping inside `api/*` if your backend shape differs — nothing else changes.

## Auto refresh flow
1. Request interceptor attaches `Authorization: Bearer <access>`.
2. On 401, the first failing request calls `/auth/refresh` (via a bare axios instance, no interceptors).
3. Other 401s during that time await the **same** refresh promise, then retry with the new token.
4. If refresh fails → tokens cleared → redirect to `/login`.
5. Requests flagged `{ skipAuth: true }` (login/refresh) are never retried.

## Sekar Batik storefront sync

The CMS is the admin for the `ecommerce-batik` store.

- **Products** carry the storefront fields: `slug`, `gender` (Wanita/Pria/Unisex), `category` (Kain/Kemeja/Blouse/Dress/Scarf), `origin`, `technique`, `pattern`, `colors[3]`, `description`, `material`, `dimensions` and per-size `variants[{ size, stock }]`. `stock` is the computed total. `isActive` = visible in shop.
- **Orders** (`/orders`) are created by the store's checkout; the CMS lists them and changes `status` (pending → paid → shipped → completed / cancelled) via `PUT /orders/:id { status }`.
- Contract: `app/types/product.ts`, `app/types/order.ts` ↔ `ecommerce-batik/types/catalog.ts`.

go_koecms still needs: the new product fields, `/orders` (GET list/get, PUT status), and public `GET /shop/products` + `POST /shop/orders` (see ecommerce-batik README).
