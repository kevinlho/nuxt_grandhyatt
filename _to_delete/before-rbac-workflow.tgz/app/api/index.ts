import type { AxiosInstance } from 'axios'
import type { Product, ProductInput } from '~/types/product'
import type { Order, OrderStatusInput } from '~/types/order'
import type { User, UserInput } from '~/types/user'
import { totalStock } from '~/types/product'
import { authApi } from './auth'
import { crudApi } from './crud'
import { mockAuthApi } from './mock/auth'
import { mockCrud } from './mock/crud'
import { orders, products, users } from './mock/db'

/** All backend calls in one place. Add a new resource = one line here. */
export function createApi(http: AxiosInstance, useDummy: boolean) {
  if (useDummy) {
    return {
      auth: mockAuthApi,
      users: mockCrud<User, UserInput>(users, {
        label: 'User', searchFields: ['name', 'email', 'role'],
        unique: (rows, i, id) => rows.some(u => u.email === i.email && u.id !== id) ? 'Email already exists' : undefined
      }),
      products: mockCrud<Product, ProductInput>(products, {
        label: 'Product', searchFields: ['name', 'sku', 'slug', 'category', 'gender', 'origin'],
        unique: (rows, i, id) =>
          rows.some(p => p.sku === i.sku && p.id !== id) ? 'SKU already exists'
          : rows.some(p => p.slug === i.slug && p.id !== id) ? 'Slug already exists' : undefined,
        prepare: p => ({ ...p, stock: totalStock(p.variants) })
      }),
      // orders are created by the storefront; the CMS only lists them and changes status
      orders: mockCrud<Order, OrderStatusInput>(orders, {
        label: 'Order', searchFields: ['code', 'customerName', 'email', 'phone', 'city', 'status']
      })
    }
  }
  return {
    auth: authApi(http),
    users: crudApi<User, UserInput>(http, '/users'),
    products: crudApi<Product, ProductInput>(http, '/products'),
    orders: crudApi<Order, OrderStatusInput>(http, '/orders')
  }
}

export type Api = ReturnType<typeof createApi>
