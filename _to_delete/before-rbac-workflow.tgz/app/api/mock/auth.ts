import type { AuthApi } from '../auth'
import { delay, uid } from './db'

const tokens = () => ({ accessToken: `dummy-access-${uid()}`, refreshToken: `dummy-refresh-${uid()}` })

// Demo login: admin@example.com / password
export const mockAuthApi: AuthApi = {
  async login(c) {
    await delay()
    if (c.email !== 'admin@example.com' || c.password !== 'password') throw new Error('Invalid email or password')
    return { tokens: tokens(), user: { id: '1', name: 'Admin', email: c.email, role: 'admin' } }
  },
  async refresh() { await delay(200); return tokens() },
  async logout() { await delay(150) }
}
