import type { User } from '~/types/user'
import type { Product } from '~/types/product'
import type { Order } from '~/types/order'
import { batikOrders, batikProducts } from './batik'
import type { PageQuery, Paginated } from '~/types/pagination'

export const delay = (ms = 400) => new Promise(r => setTimeout(r, ms))
export const uid = () => Math.random().toString(36).slice(2, 10)

const roles = ['admin', 'editor', 'viewer'] as const
const firstNames = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eka', 'Fajar', 'Gita', 'Hadi', 'Indah', 'Joko', 'Kartika', 'Lukas']

export const users: User[] = Array.from({ length: 24 }, (_, i) => {
  const n = firstNames[i % firstNames.length]!
  return {
    id: uid(),
    name: `${n} ${String.fromCharCode(65 + (i % 26))}.`,
    email: `${n.toLowerCase()}${i + 1}@example.com`,
    role: roles[i % 3]!,
    status: i % 5 === 0 ? 'inactive' : 'active',
    createdAt: new Date(Date.now() - i * 86400000 * 3).toISOString()
  }
})

export const products: Product[] = batikProducts(uid)
export const orders: Order[] = batikOrders(uid, products)

export function paginate<T>(rows: T[], q: PageQuery, searchFields: (keyof T)[]): Paginated<T> {
  const s = q.search?.trim().toLowerCase()
  const filtered = s
    ? rows.filter(r => searchFields.some(f => String(r[f]).toLowerCase().includes(s)))
    : rows
  const start = (q.page - 1) * q.pageSize
  return { items: filtered.slice(start, start + q.pageSize), total: filtered.length, page: q.page, pageSize: q.pageSize }
}
