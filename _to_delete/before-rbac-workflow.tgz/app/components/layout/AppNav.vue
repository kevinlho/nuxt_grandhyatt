<script setup lang="ts">
// Shared navigation used by the desktop sidebar and the mobile drawer.
const emit = defineEmits<{ navigate: [] }>()
const { user, logout } = useAuth()
const route = useRoute()
const links = [
  { label: 'Dashboard', icon: 'i-lucide-layout-dashboard', to: '/' },
  { label: 'Users', icon: 'i-lucide-users', to: '/users' },
  { label: 'Products', icon: 'i-lucide-package', to: '/products' },
  { label: 'Orders', icon: 'i-lucide-shopping-bag', to: '/orders' }
]
const isActive = (to: string) => to === '/' ? route.path === '/' : route.path.startsWith(to)
</script>

<template>
  <div class="h-full flex flex-col">
    <div class="h-16 shrink-0 flex items-center px-5 font-bold text-lg">
      <UIcon name="i-lucide-box" class="mr-2 text-primary" /> CMS
    </div>
    <nav class="flex-1 overflow-y-auto px-3 space-y-1" aria-label="Main">
      <UButton
        v-for="l in links" :key="l.to" :to="l.to" :icon="l.icon" :label="l.label"
        block size="lg" class="justify-start" :variant="isActive(l.to) ? 'soft' : 'ghost'"
        :color="isActive(l.to) ? 'primary' : 'neutral'"
        :aria-current="isActive(l.to) ? 'page' : undefined"
        @click="emit('navigate')"
      />
    </nav>
    <div class="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] border-t border-(--ui-border) flex items-center gap-2">
      <UAvatar :alt="user?.name" size="sm" />
      <div class="flex-1 min-w-0 text-sm">
        <p class="font-medium truncate">{{ user?.name }}</p>
        <p class="text-(--ui-text-muted) truncate">{{ user?.email }}</p>
      </div>
      <UButton icon="i-lucide-log-out" color="neutral" variant="ghost" aria-label="Log out" @click="logout" />
    </div>
  </div>
</template>
