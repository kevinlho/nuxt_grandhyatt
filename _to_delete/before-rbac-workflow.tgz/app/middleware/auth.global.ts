import { tokenStorage } from '~/utils/tokenStorage'

export default defineNuxtRouteMiddleware((to) => {
  const loggedIn = !!tokenStorage.getAccessToken()
  if (to.meta.public) {
    if (loggedIn && to.path === '/login') return navigateTo('/')
    return
  }
  if (!loggedIn) return navigateTo({ path: '/login', query: { redirect: to.fullPath } })
})
