import type { ProductInput } from '~/types/product'
import type { UserInput } from '~/types/user'

// Quick client-side checks for nicer UX. The Go backend is still the source of truth.
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/
const HEX_RE = /^#[0-9a-fA-F]{6}$/

export function validateUser(i: UserInput) {
  if (!i.name.trim()) return 'Name is required'
  if (!EMAIL_RE.test(i.email)) return 'Invalid email'
}

export function validateProduct(i: ProductInput) {
  if (!i.name.trim()) return 'Name is required'
  if (!SLUG_RE.test(i.slug)) return 'Slug must be lowercase letters, numbers and dashes'
  if (!i.sku.trim()) return 'SKU is required'
  if (i.price < 0) return 'Price cannot be negative'
  if (!i.origin.trim()) return 'Origin is required'
  if (i.colors.some(c => !HEX_RE.test(c))) return 'Colors must be hex values like #5b3a22'
  if (!i.variants.length) return 'Add at least one size'
  if (i.variants.some(v => !v.size.trim())) return 'Every variant needs a size'
  if (new Set(i.variants.map(v => v.size)).size !== i.variants.length) return 'Sizes must be unique'
  if (i.variants.some(v => v.stock < 0)) return 'Stock cannot be negative'
}
