import type { User } from '~/types/user'
import type { Role } from '~/types/rbac'
import type { Department } from '~/types/department'
import type { WorkflowRequest, WorkflowTemplate } from '~/types/workflow'
import type { Product } from '~/types/product'
import type { Order } from '~/types/order'
import { batikOrders, batikProducts } from './batik'
import type { PageQuery, Paginated } from '~/types/pagination'

export const delay = (ms = 400) => new Promise(r => setTimeout(r, ms))
export const uid = () => Math.random().toString(36).slice(2, 10)

const day = 86400000
const ago = (d: number) => new Date(Date.now() - d * day).toISOString()

export const departments: Department[] = [
  { id: 'd-exec', code: 'EXEC', name: 'Executive Office', description: 'Leadership and strategy.', headUserId: '2', createdAt: ago(90) },
  { id: 'd-fo', code: 'FO', name: 'Front Office', description: 'Reception, concierge and guest relations.', headUserId: '3', createdAt: ago(90) },
  { id: 'd-fnb', code: 'FNB', name: 'Food & Beverage', description: 'Restaurants, bars and banquets.', createdAt: ago(90) },
  { id: 'd-hk', code: 'HK', name: 'Housekeeping', description: 'Rooms and public areas.', createdAt: ago(90) },
  { id: 'd-fin', code: 'FIN', name: 'Finance', description: 'Accounting and purchasing.', createdAt: ago(90) },
  { id: 'd-it', code: 'IT', name: 'IT', description: 'Systems and the CMS.', headUserId: '1', createdAt: ago(90) }
]

export const roles: Role[] = [
  { id: uid(), key: 'admin', name: 'Administrator', level: 99, permissions: ['*'], isSystem: true, createdAt: ago(60) },
  { id: uid(), key: 'ceo', name: 'CEO', level: 3, createdAt: ago(60), permissions: [
    'users.view', 'departments.view', 'roles.view', 'products.view', 'orders.view',
    'workflows.create', 'workflows.approve', 'workflows.view_all'] },
  { id: uid(), key: 'manager', name: 'Manager', level: 2, createdAt: ago(60), permissions: [
    'users.view', 'departments.view', 'products.view', 'products.manage', 'orders.view', 'orders.manage',
    'workflows.create', 'workflows.approve'] },
  { id: uid(), key: 'employee', name: 'Employee', level: 1, createdAt: ago(60), permissions: [
    'products.view', 'orders.view', 'workflows.create'] },
  { id: uid(), key: 'editor', name: 'Editor', level: 0, createdAt: ago(60), permissions: [
    'products.view', 'products.manage', 'orders.view', 'orders.manage'] },
  { id: uid(), key: 'viewer', name: 'Viewer', level: 0, createdAt: ago(60), permissions: [
    'products.view', 'orders.view'] }
]

const seedRoles = ['employee', 'manager', 'editor', 'viewer', 'employee'] as const
const firstNames = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eka', 'Fajar', 'Gita', 'Hadi', 'Indah', 'Joko', 'Kartika', 'Lukas']

// fixed demo accounts (password: "password") — see mock/auth.ts
const demo: User[] = [
  { id: '1', name: 'Admin', email: 'admin@example.com', role: 'admin', departmentId: 'd-it', status: 'active', createdAt: ago(60) },
  { id: '2', name: 'Bambang (CEO)', email: 'ceo@example.com', role: 'ceo', departmentId: 'd-exec', status: 'active', createdAt: ago(59) },
  { id: '3', name: 'Maria (Manager)', email: 'manager@example.com', role: 'manager', departmentId: 'd-fo', status: 'active', createdAt: ago(58) },
  { id: '4', name: 'Eko (Employee)', email: 'employee@example.com', role: 'employee', departmentId: 'd-fo', status: 'active', createdAt: ago(57) }
]

export const users: User[] = [...demo, ...Array.from({ length: 20 }, (_, i): User => {
  const n = firstNames[i % firstNames.length]!
  return {
    id: uid(),
    name: `${n} ${String.fromCharCode(65 + (i % 26))}.`,
    email: `${n.toLowerCase()}${i + 1}@example.com`,
    role: seedRoles[i % seedRoles.length]!,
    departmentId: i % 7 === 6 ? null : departments[1 + (i % 5)]!.id,
    status: i % 5 === 0 ? 'inactive' : 'active',
    createdAt: new Date(Date.now() - i * 86400000 * 3).toISOString()
  }
})]

export const products: Product[] = batikProducts(uid)
export const orders: Order[] = batikOrders(uid, products)

export const workflowTemplates: WorkflowTemplate[] = [
  { id: uid(), name: 'Purchase Request', description: 'Buying goods or services for the hotel.', isActive: true, createdAt: ago(30),
    steps: [{ roleKey: 'manager', label: 'Department review' }, { roleKey: 'ceo', label: 'Final approval' }] },
  { id: uid(), name: 'Leave Request', description: 'Annual or special leave.', isActive: true, createdAt: ago(30),
    steps: [{ roleKey: 'manager', label: 'Line manager' }] },
  { id: uid(), name: 'Content Publication', description: 'Publishing new promotional content.', isActive: true, createdAt: ago(30),
    steps: [{ roleKey: 'manager' }, { roleKey: 'ceo' }] }
]

/** filled by mock/workflow.ts on first use (needs the rules there) */
export const workflowRequests: WorkflowRequest[] = []

export function paginate<T>(rows: T[], q: PageQuery, searchFields: (keyof T)[]): Paginated<T> {
  const s = q.search?.trim().toLowerCase()
  let filtered = s
    ? rows.filter(r => searchFields.some(f => String(r[f]).toLowerCase().includes(s)))
    : rows
  // equality filters for any other non-empty param ('none' matches empty)
  for (const [k, v] of Object.entries(q)) {
    if (['page', 'pageSize', 'search'].includes(k) || v === '' || v == null) continue
    filtered = filtered.filter(r => {
      const x = (r as Record<string, unknown>)[k]
      return v === 'none' ? x == null || x === '' : String(x) === String(v)
    })
  }
  const start = (q.page - 1) * q.pageSize
  return { items: filtered.slice(start, start + q.pageSize), total: filtered.length, page: q.page, pageSize: q.pageSize }
}
