<script setup lang="ts">
import type { Permission } from '~/types/rbac'

// Shared navigation used by the desktop sidebar and the mobile drawer.
const emit = defineEmits<{ navigate: [] }>()
const { user, logout } = useAuth()
const { can } = usePermission()
const { $api } = useNuxtApp()
const route = useRoute()

const all: { label: string; icon: string; to: string; permission?: Permission | Permission[]; badge?: 'inbox' }[] = [
  { label: 'Dashboard', icon: 'i-lucide-layout-dashboard', to: '/' },
  { label: 'Workflows', icon: 'i-lucide-git-pull-request-arrow', to: '/workflows', permission: ['workflows.create', 'workflows.approve', 'workflows.view_all'], badge: 'inbox' },
  { label: 'Approval Flows', icon: 'i-lucide-route', to: '/workflows/templates', permission: 'workflows.manage' },
  { label: 'Users', icon: 'i-lucide-users', to: '/users', permission: 'users.view' },
  { label: 'Departments', icon: 'i-lucide-building-2', to: '/departments', permission: 'departments.view' },
  { label: 'Roles & Access', icon: 'i-lucide-shield-check', to: '/roles', permission: 'roles.view' },
  { label: 'Products', icon: 'i-lucide-package', to: '/products', permission: 'products.view' },
  { label: 'Orders', icon: 'i-lucide-shopping-bag', to: '/orders', permission: 'orders.view' }
]
const links = computed(() => all.filter(l => !l.permission || can(l.permission)))

// requests waiting for my decision; refreshed on navigation
const inbox = useState('workflow.inbox', () => 0)
async function refreshInbox() {
  if (!can(['workflows.approve'])) return
  try { inbox.value = await $api.workflows.inboxCount() } catch { /* ignore */ }
}
watch(() => route.fullPath, refreshInbox, { immediate: true })

const isActive = (to: string) => {
  if (to === '/') return route.path === '/'
  // most specific link wins (/workflows vs /workflows/templates)
  const best = all.filter(l => l.to !== '/' && route.path.startsWith(l.to)).sort((a, b) => b.to.length - a.to.length)[0]
  return best?.to === to
}
</script>

<template>
  <div class="h-full flex flex-col">
    <div class="h-16 shrink-0 flex items-center px-5 font-bold text-lg">
      <UIcon name="i-lucide-box" class="mr-2 text-primary" /> CMS
    </div>
    <nav class="flex-1 overflow-y-auto px-3 space-y-1" aria-label="Main">
      <UButton
        v-for="l in links" :key="l.to" :to="l.to" :icon="l.icon" :label="l.label"
        block size="lg" class="justify-start" :variant="isActive(l.to) ? 'soft' : 'ghost'"
        :color="isActive(l.to) ? 'primary' : 'neutral'"
        :aria-current="isActive(l.to) ? 'page' : undefined"
        @click="emit('navigate')"
      >
        <template v-if="l.badge === 'inbox' && inbox" #trailing>
          <UBadge :label="String(inbox)" color="warning" size="sm" class="ml-auto" :aria-label="`${inbox} waiting for your approval`" />
        </template>
      </UButton>
    </nav>
    <div class="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] border-t border-(--ui-border) flex items-center gap-2">
      <UAvatar :alt="user?.name" size="sm" />
      <div class="flex-1 min-w-0 text-sm">
        <p class="font-medium truncate">{{ user?.name }}</p>
        <p class="text-(--ui-text-muted) truncate">{{ user?.roleName ?? user?.role }} · {{ user?.email }}</p>
      </div>
      <UButton icon="i-lucide-log-out" color="neutral" variant="ghost" aria-label="Log out" @click="logout" />
    </div>
  </div>
</template>
