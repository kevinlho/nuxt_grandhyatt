/**
 * Document library contract.
 * Files are sorted into a category (auto-suggested from the file name/type, confirmed by the uploader)
 * and belong to a department. `visibility` decides who can retrieve them.
 */
export const DOC_CATEGORIES = [
  { key: 'sop', label: 'SOP', icon: 'i-lucide-list-checks' },
  { key: 'policy', label: 'Policy', icon: 'i-lucide-scale' },
  { key: 'form', label: 'Forms & Templates', icon: 'i-lucide-file-pen-line' },
  { key: 'training', label: 'Training', icon: 'i-lucide-graduation-cap' },
  { key: 'manual', label: 'Manuals & Guides', icon: 'i-lucide-book-open' },
  { key: 'report', label: 'Reports', icon: 'i-lucide-chart-column' },
  { key: 'contract', label: 'Contracts', icon: 'i-lucide-file-signature' },
  { key: 'menu', label: 'Menus & Recipes', icon: 'i-lucide-utensils' },
  { key: 'media', label: 'Images & Media', icon: 'i-lucide-image' },
  { key: 'other', label: 'Other', icon: 'i-lucide-file' }
] as const
export type DocCategory = typeof DOC_CATEGORIES[number]['key']

export type DocVisibility = 'everyone' | 'department'
export type DocStatus = 'active' | 'archived'

export interface DocumentFile {
  id: string
  title: string
  description: string
  category: DocCategory
  tags: string[]
  departmentId?: string | null
  visibility: DocVisibility
  status: DocStatus
  fileName: string
  mimeType: string
  extension: string     // 'pdf', 'docx', …
  size: number          // bytes
  url: string           // download / preview URL
  uploadedById: string
  uploadedByName: string
  createdAt: string
  updatedAt: string
}

/** editable details (the file itself is replaced only by uploading a new document) */
export interface DocumentMeta {
  title: string
  description: string
  category: DocCategory
  tags: string[]
  departmentId?: string | null
  visibility: DocVisibility
}

export interface DocumentUpload extends DocumentMeta { file: File }

export type DocSort = 'newest' | 'oldest' | 'name' | 'size'

export const DOC_LIMITS = {
  maxBytes: 25 * 1024 * 1024,
  maxFiles: 10,
  accept: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'md', 'png', 'jpg', 'jpeg', 'webp']
}

/** file-type groups for the type filter and icons */
export const FILE_KINDS: Record<string, { label: string; icon: string; color: string; exts: string[] }> = {
  pdf: { label: 'PDF', icon: 'i-lucide-file-text', color: 'text-red-500', exts: ['pdf'] },
  doc: { label: 'Word', icon: 'i-lucide-file-type', color: 'text-blue-500', exts: ['doc', 'docx', 'md', 'txt'] },
  sheet: { label: 'Excel / CSV', icon: 'i-lucide-file-spreadsheet', color: 'text-green-600', exts: ['xls', 'xlsx', 'csv'] },
  slide: { label: 'PowerPoint', icon: 'i-lucide-presentation', color: 'text-orange-500', exts: ['ppt', 'pptx'] },
  image: { label: 'Image', icon: 'i-lucide-file-image', color: 'text-purple-500', exts: ['png', 'jpg', 'jpeg', 'webp'] }
}
export const kindOf = (ext: string) => Object.entries(FILE_KINDS).find(([, k]) => k.exts.includes(ext.toLowerCase()))?.[0] ?? 'other'
export const categoryOf = (key: string) => DOC_CATEGORIES.find(c => c.key === key) ?? DOC_CATEGORIES[DOC_CATEGORIES.length - 1]
