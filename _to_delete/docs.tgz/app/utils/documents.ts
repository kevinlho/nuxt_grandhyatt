import type { DocCategory } from '~/types/document'

export const fileExt = (name: string) => (name.includes('.') ? name.split('.').pop()!.toLowerCase() : '')

/** "SOP_Check-in_v2.pdf" → "SOP Check-in v2" */
export const titleFromFile = (name: string) =>
  name.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim()

const RULES: [DocCategory, RegExp][] = [
  ['sop', /\b(sop|standard operating|procedure|prosedur|checklist)\b/i],
  ['policy', /\b(policy|policies|kebijakan|peraturan|regulation|code of conduct|handbook)\b/i],
  ['form', /\b(form|formulir|template|request form|application)\b/i],
  ['training', /\b(training|pelatihan|onboarding|module|course|quiz)\b/i],
  ['manual', /\b(manual|guide|panduan|instruction|how ?to|user guide)\b/i],
  ['report', /\b(report|laporan|summary|analysis|kpi|forecast|budget|p&l)\b/i],
  ['contract', /\b(contract|kontrak|agreement|perjanjian|mou|nda|sla)\b/i],
  ['menu', /\b(menu|recipe|resep|banquet|bev|beverage|wine list)\b/i]
]

/** Auto-sort: guess a category from the file name, falling back to the file type. */
export function suggestCategory(fileName: string): DocCategory {
  const text = titleFromFile(fileName).replace(/[-.]/g, ' ')
  for (const [cat, re] of RULES) if (re.test(text)) return cat
  return ['png', 'jpg', 'jpeg', 'webp'].includes(fileExt(fileName)) ? 'media' : 'other'
}

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`
  return `${(n / 1024 / 1024).toFixed(1)} MB`
}
